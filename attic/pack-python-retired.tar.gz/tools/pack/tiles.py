"""Tileset model: effective corner/edge signatures under rotation, and adjacency checks.

Compass names: corners NW,NE,SW,SE (set keys TopLeft,TopRight,BottomLeft,BottomRight);
edges N,E,S,W (set keys Top,Right,Bottom,Left). Rotation conventions are verified
against stock areas by check_conventions.py, never assumed.
"""
CORNER_KEYS = {"NW": "TopLeft", "NE": "TopRight", "SW": "BottomLeft", "SE": "BottomRight"}
EDGE_KEYS = {"N": "Top", "E": "Right", "S": "Bottom", "W": "Left"}
CORNER_CCW = ["NW", "SW", "SE", "NE"]  # counter-clockwise order (as seen from above)
EDGE_CCW = ["N", "W", "S", "E"]


def _rot(order, pos, k, ccw):
    i = order.index(pos)
    return order[(i + (k if ccw else -k)) % 4]


def tile_sig(tile, o, ccw=True):
    """Effective signature of `tile` (a parsed [TILEn] dict) at orientation o.
    Returns (corners{NW,NE,SW,SE}->terrain, cheights, edges{N,E,S,W}->crosser)."""
    corners, heights, edges = {}, {}, {}
    for pos, key in CORNER_KEYS.items():
        dst = _rot(CORNER_CCW, pos, o, ccw)
        corners[dst] = tile[key]
        heights[dst] = int(tile.get(key + "Height", "0") or 0)
    for pos, key in EDGE_KEYS.items():
        dst = _rot(EDGE_CCW, pos, o, ccw)
        edges[dst] = tile.get(key, "")
    return corners, heights, edges


def cell_xy(i, w, h, order):
    """Map Tile_List index -> (x east, y north) for the candidate index orders."""
    if order == "row_bottom":   # rows from the south, west->east
        return i % w, i // w
    if order == "row_top":      # rows from the north
        return i % w, h - 1 - i // w
    if order == "col_left":     # columns from the west, south->north
        return i // h, i % h
    if order == "col_right":
        return w - 1 - i // h, i % h
    raise ValueError(order)


ORDERS = ["row_bottom", "row_top", "col_left", "col_right"]


def violations(area, tiles, order, ccw, use_heights=True):
    """Count adjacency violations in one stock area. `tiles` = set tile dicts."""
    w, h = area["width"], area["height"]
    grid = {}
    for i, t in enumerate(area["tiles"]):
        x, y = cell_xy(i, w, h, order)
        grid[(x, y)] = tile_sig(tiles[t["Tile_ID"]], t["Tile_Orientation"], ccw)
    bad = 0
    for (x, y), (c, ch, e) in grid.items():
        if (x + 1, y) in grid:
            c2, ch2, e2 = grid[(x + 1, y)]
            for a, b in (("NE", "NW"), ("SE", "SW")):
                bad += c[a] != c2[b]
                if use_heights:
                    bad += ch[a] != ch2[b]
            bad += e["E"] != e2["W"]
        if (x, y + 1) in grid:
            c2, ch2, e2 = grid[(x, y + 1)]
            for a, b in (("NW", "SW"), ("NE", "SE")):
                bad += c[a] != c2[b]
                if use_heights:
                    bad += ch[a] != ch2[b]
            bad += e["N"] != e2["S"]
    return bad
