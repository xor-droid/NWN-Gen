"""Step 1a: extract every stock ARE (as JSON) whose tileset we care about.
usage: scan_stock_areas.py OUT.json tileset [tileset...]
Writes {archive: {area: {tileset,width,height,tiles:[...]}}}."""
import json
import os
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *  # noqa

out_path, wanted = sys.argv[1], set(t.lower() for t in sys.argv[2:])
result = {}
for arc in stock_archives():
    names = [l for l in tool("nwn_erf", "-f", arc, "-t").stdout.splitlines() if l.lower().endswith(".are")]
    for n in names:
        with tempfile.TemporaryDirectory(dir=WORK()) as td:
            tool("nwn_erf", "-f", arc, "-x", n, cwd=td)
            a = gff_to_json(os.path.join(td, n))
        ts = a["Tileset"]["value"].lower()
        if ts not in wanted:
            continue
        tiles = [{k: v["value"] for k, v in t.items() if k != "__struct_id"} for t in a["Tile_List"]["value"]]
        result.setdefault(os.path.basename(arc), {})[n] = {
            "tileset": ts, "width": a["Width"]["value"], "height": a["Height"]["value"], "tiles": tiles}
    print(os.path.basename(arc), sum(1 for _ in result.get(os.path.basename(arc), {})), "areas", file=sys.stderr)
json.dump(result, open(out_path, "w"), sort_keys=True)
print("total areas:", sum(len(v) for v in result.values()), file=sys.stderr)
