"""Export the template files the generator needs, from stock data in your install:
  tpl_are.json / tpl_are.are   donor ARE (header, lighting; Tile_List emptied)
  tpl_git.json / tpl_git.git   AreaProperties + one clone-source waypoint and transition trigger
  base_module.mod              base module: stock IFO (area list emptied), repute.fac
usage: export_templates.py OUTDIR      (env as in README; needs build/erfpack via ERFPACK)"""
import os, shutil, subprocess, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from area import *  # noqa

out = sys.argv[1]
os.makedirs(out, exist_ok=True)
donor = load_donor()
are = copy.deepcopy(donor["are"]); are["Tile_List"] = v("list", [])
git = {"__data_type": "GIT ", "AreaProperties": copy.deepcopy(donor["git"]["AreaProperties"])}
for k in GIT_LISTS:
    git[k] = v("list", [])
git["WaypointList"] = v("list", [make_waypoint("TPL_WAYPOINT", 5.0, 5.0, 0.0, 1.0, name="template")])
git["TriggerList"] = v("list", [make_transition(donor_transition_trigger(), "TPL_TRIGGER", "TPL_WAYPOINT", 5.0, 5.0, name="template")])
for obj, name in ((are, "tpl_are"), (git, "tpl_git")):
    json.dump(obj, open(os.path.join(out, name + ".json"), "w"), sort_keys=True)
    json_to_gff(obj, os.path.join(out, name + (".are" if obj is are else ".git")))
# base module = stock IFO (areas removed) + repute.fac
dr = os.path.join(WORK(), "donor_mod"); shutil.rmtree(dr, ignore_errors=True); os.makedirs(dr)
tool("nwn_erf", "-f", os.path.join(ROOT(), "data", "mod", "The Dark Ranger's Treasure.mod"), "-x", cwd=dr)
found = {f.lower(): f for f in os.listdir(dr)}
ifo = gff_to_json(os.path.join(dr, found["module.ifo"]))
for k in [k for k in ifo if k.startswith("Mod_On")]:
    ifo[k] = v("resref", "")
for k, s in (("Mod_OnPlrDeath", "nw_o0_death"), ("Mod_OnPlrDying", "nw_o0_dying"), ("Mod_OnSpawnBtnDn", "nw_o0_respawn")):
    ifo[k] = v("resref", s)
ifo["Mod_Area_list"] = v("list", [])
stage = os.path.join(out, "base_stage"); shutil.rmtree(stage, ignore_errors=True); os.makedirs(stage)
json.dump(ifo, open(os.path.join(out, "base_ifo.json"), "w"), sort_keys=True)
json_to_gff(ifo, os.path.join(stage, "module.ifo"))
shutil.copy(os.path.join(dr, found["repute.fac"]), os.path.join(stage, "repute.fac"))
subprocess.run([os.environ["ERFPACK"], "nwn1", "MOD", os.path.join(out, "base_module.mod"), stage], check=True)
shutil.rmtree(stage)
print("wrote templates to", out)
