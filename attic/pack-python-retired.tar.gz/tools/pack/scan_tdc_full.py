"""Capture FULL ARE+GIT JSON for every stock area of one tileset (template source).
usage: scan_tdc_full.py OUT.json tileset"""
import json, os, sys, tempfile
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *  # noqa
out_path, ts = sys.argv[1], sys.argv[2].lower()
res = {}
for arc in stock_archives():
    listing = tool("nwn_erf", "-f", arc, "-t").stdout.splitlines()
    for n in [l for l in listing if l.lower().endswith(".are")]:
        base = n[:-4]
        with tempfile.TemporaryDirectory(dir=WORK()) as td:
            tool("nwn_erf", "-f", arc, "-x", n, cwd=td)
            a = gff_to_json(os.path.join(td, n))
            if a["Tileset"]["value"].lower() != ts:
                continue
            g = None
            if base + ".git" in listing:
                tool("nwn_erf", "-f", arc, "-x", base + ".git", cwd=td)
                g = gff_to_json(os.path.join(td, base + ".git"))
        res["%s:%s" % (os.path.basename(arc), base)] = {"are": a, "git": g}
json.dump(res, open(out_path, "w"), sort_keys=True)
print(len(res), "areas captured")
