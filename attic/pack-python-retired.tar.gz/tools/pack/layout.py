"""Procedural dungeon layouts on the tile-corner lattice.

A layout is a (W+1)x(H+1) lattice of vertex labels 'W'/'F'. A cell (x,y) (x east, y north)
has corners NW=(x,y+1) NE=(x+1,y+1) SW=(x,y) SE=(x+1,y). Any labelling without diagonal
patterns is tileable from the stock-proven pool, so validity is by construction and is
re-checked by the same adjacency function that passes every stock area.
"""
FORBIDDEN = {("F", "W", "W", "F"), ("W", "F", "F", "W")}  # (NW,NE,SW,SE) diagonals


def cell_sig(lat, x, y):
    return (lat[y + 1][x], lat[y + 1][x + 1], lat[y][x], lat[y][x + 1])


def _carve(lat, x0, y0, x1, y1):
    for y in range(y0, y1 + 1):
        for x in range(x0, x1 + 1):
            lat[y][x] = "F"


def _fix_diagonals(lat, W, H):
    """Open the wall vertex of any diagonal cell. Returns False if a border vertex
    would be needed (caller regenerates)."""
    for _ in range(W * H):
        changed = False
        for y in range(H):
            for x in range(W):
                s = cell_sig(lat, x, y)
                if s in FORBIDDEN:
                    # candidates: the two wall vertices of this cell
                    ws = [(vx, vy) for (vx, vy), l in zip(
                        ((x, y + 1), (x + 1, y + 1), (x, y), (x + 1, y)), s) if l == "W"]
                    inner = [v for v in ws if 0 < v[0] < W and 0 < v[1] < H]
                    if not inner:
                        return False
                    vx, vy = inner[0]
                    lat[vy][vx] = "F"
                    changed = True
        if not changed:
            return True
    return False


def full_floor_cells(lat, W, H):
    return {(x, y) for y in range(H) for x in range(W) if cell_sig(lat, x, y) == ("F",) * 4}


def components(cells):
    """4-connected components of a set of cells."""
    left, comps = set(cells), []
    while left:
        start = min(left)
        comp, stack = set(), [start]
        while stack:
            c = stack.pop()
            if c in comp:
                continue
            comp.add(c)
            for d in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                n = (c[0] + d[0], c[1] + d[1])
                if n in left and n not in comp:
                    stack.append(n)
        left -= comp
        comps.append(comp)
    return comps


def make_layout(rng, W, H, nrooms, room_min=2, room_max=4):
    """Rooms joined in a chain by 1-cell-wide L corridors. Deterministic in rng.
    Returns dict(lat, rooms[(cx0,cy0,cx1,cy1) in cells], W, H)."""
    for attempt in range(200):
        lat = [["W"] * (W + 1) for _ in range(H + 1)]
        rooms = []
        for _ in range(nrooms * 20):
            if len(rooms) == nrooms:
                break
            rw, rh = rng.range(room_min, room_max), rng.range(room_min, room_max)
            if rw > W - 2 or rh > H - 2:
                continue
            cx, cy = rng.range(1, W - 1 - rw), rng.range(1, H - 1 - rh)  # cells; vertices cx..cx+rw
            # keep >=1 wall vertex between rooms (vertex rects must not touch)
            if any(not (cx + rw + 1 < r[0] or r[2] + 1 < cx or cy + rh + 1 < r[1] or r[3] + 1 < cy)
                   for r in rooms):
                continue
            rooms.append((cx, cy, cx + rw, cy + rh))
        if len(rooms) < nrooms:
            continue
        rooms.sort(key=lambda r: (r[0], r[1]))  # stable chain order
        for r in rooms:
            _carve(lat, r[0], r[1], r[2], r[3])
        for a, b in zip(rooms, rooms[1:]):
            ax, ay = (a[0] + a[2]) // 2, (a[1] + a[3]) // 2
            bx, by = (b[0] + b[2]) // 2, (b[1] + b[3]) // 2
            ax = min(max(ax, 1), W - 2); bx = min(max(bx, 1), W - 2)
            ay = min(max(ay, 1), H - 2); by = min(max(by, 1), H - 2)
            # L: horizontal at ay then vertical at bx; corridor = 2 vertices wide
            _carve(lat, min(ax, bx), ay, max(ax, bx) + 1, ay + 1)
            _carve(lat, bx, min(ay, by), bx + 1, max(ay, by) + 1)
        if not _fix_diagonals(lat, W, H):
            continue
        if any(lat[0][x] == "F" or lat[H][x] == "F" for x in range(W + 1)) or \
           any(lat[y][0] == "F" or lat[y][W] == "F" for y in range(H + 1)):
            continue  # border must remain wall
        if any(cell_sig(lat, x, y) in FORBIDDEN for y in range(H) for x in range(W)):
            continue
        ff = full_floor_cells(lat, W, H)
        if len(components(ff)) != 1:
            continue
        return {"lat": lat, "rooms": rooms, "W": W, "H": H, "attempts": attempt + 1}
    raise RuntimeError("could not generate a valid layout")


def render(layout):
    """ASCII picture: '#' wall-only cell, '.' partial, 'o' full floor (north at top)."""
    lat, W, H = layout["lat"], layout["W"], layout["H"]
    ff = full_floor_cells(lat, W, H)
    rows = []
    for y in range(H - 1, -1, -1):
        rows.append("".join("o" if (x, y) in ff else ("#" if cell_sig(lat, x, y) == ("W",) * 4 else ".")
                            for x in range(W)))
    return "\n".join(rows)


def portal_pair(layout, room_index, rng):
    """Two 4-adjacent full-floor cells inside one room: (portal_cell, arrive_cell).
    Deterministic in rng. The pair is chosen from cells strictly inside the room."""
    ff = full_floor_cells(layout["lat"], layout["W"], layout["H"])
    r = layout["rooms"][room_index]
    room_cells = sorted(c for c in ff if r[0] <= c[0] < r[2] and r[1] <= c[1] < r[3])
    pairs = [(a, b) for a in room_cells for b in ((a[0] + 1, a[1]), (a[0], a[1] + 1),
                                                  (a[0] - 1, a[1]), (a[0], a[1] - 1)) if b in room_cells]
    if not pairs:
        raise RuntimeError("room has no adjacent full-floor cell pair")
    return rng.pick(pairs)
