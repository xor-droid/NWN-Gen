"""Python REFERENCE MODEL for the C dungeon generator (`nwndgen --recipe`).

Reads the same recipe / tilepack / template files as the C code and writes the expected
resources as JSON, so the C output can be compared field-for-field via nwn_gff.
usage: chain_ref.py RECIPE SEED BASE_MODULE_IFO.json OUTDIR     (no game install needed)

Recipe (text, '#' comments):
  nwndgen-recipe 1
  tilepack  <path>          (relative to the recipe)
  template_are <path.json>  template_git <path.json>   (JSON here; binary GFF for the C app)
  module_name <text>        module_tag <TAG>     module_description <text>
  support <min_level> <max_level> <min_party> <max_party>
  area <resref> <W> <H> <rooms> <display name...>

  chain_ref.py --dump RECIPE SEED       pure layout/tile/portal dump (compared with build/dgdump)
"""
import hashlib
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from layout import make_layout, portal_pair, render, cell_sig
from rng import Rng


def v(t, x):
    return {"type": t, "value": x}


def cell_center(x, y):
    return (x * 10.0 + 5.0, y * 10.0 + 5.0)


def area_seed(seed, resref):
    d = hashlib.sha256(b"nwndgen/layout/1\0" + seed.to_bytes(8, "big") + resref.encode()).digest()
    return int.from_bytes(d[:8], "big")


def module_id(seed, tag):
    return hashlib.sha256(b"nwndgen/modid/1\0" + seed.to_bytes(8, "big") + tag.encode()).digest()[:16]


class Pack:
    """Duck-typed stand-in for area.Kit: pool + light only (no install needed)."""

    def __init__(self, path):
        self.pool, self.light = {}, {}
        for line in open(path).read().splitlines()[2:]:
            t = line.split()
            if t[0] == "cell":
                self.pool.setdefault(tuple(t[1]), []).append((int(t[2]), int(t[3]), int(t[4])))
            elif t[0] == "light":
                self.light[int(t[1])] = tuple(int(x) for x in t[2:])

    def tile_for(self, rng, sig):
        c = self.pool.get(sig)
        if not c:
            raise KeyError("no tile for corner pattern %s" % (sig,))
        return rng.weighted([(w, (tid, o)) for w, tid, o in c])


def pick_tiles(pack, lay, rng):
    return [pack.tile_for(rng, cell_sig(lay["lat"], x, y)) for y in range(lay["H"]) for x in range(lay["W"])]


def plan_areas(recipe, seed, pack):
    """Pure part of the generator: layouts, tiles, portals. Mirrors src/dungeon.c."""
    areas, plan = recipe["areas"], []
    for i, a in enumerate(areas):
        rng = Rng(area_seed(seed, a["resref"]))
        lay = make_layout(rng, a["W"], a["H"], a["rooms"])
        tiles = pick_tiles(pack, lay, rng)
        pairs = {}
        pairs["start" if i == 0 else "prev"] = portal_pair(lay, 0, rng)
        if i < len(areas) - 1:
            pairs["next"] = portal_pair(lay, len(lay["rooms"]) - 1, rng)
        plan.append((a, lay, tiles, pairs))
    return plan


def dump(plan, seed):
    out = ["dungeon 1", "seed %d" % seed]
    for a, lay, tiles, pairs in plan:
        W, H = lay["W"], lay["H"]
        out.append("area %s %d %d attempts %d" % (a["resref"], W, H, lay["attempts"]))
        for r in lay["rooms"]:
            out.append("room %d %d %d %d" % tuple(r))
        for y in range(H, -1, -1):
            out.append("lat " + "".join(lay["lat"][y]))
        for y in range(H):
            out.append("tiles " + " ".join("%d:%d" % tiles[y * W + x] for x in range(W)))
        for k in ("start", "prev", "next"):
            if k in pairs:
                (px, py), (ax, ay) = pairs[k]
                out.append("pair %s %d %d %d %d" % (k, px, py, ax, ay))
    return "\n".join(out) + "\n"


def parse_recipe(path):
    r = {"areas": []}
    base = os.path.dirname(os.path.abspath(path))
    for line in open(path).read().splitlines():
        if not line.strip() or line.startswith("#"):
            continue
        k, _, rest = line.rstrip("\r").partition(" ")
        if k == "area":
            res, w, h, n, name = rest.split(" ", 4)
            r["areas"].append({"resref": res, "W": int(w), "H": int(h), "rooms": int(n), "name": name})
        elif k in ("tilepack", "template_are", "template_git"):
            r[k] = os.path.join(base, rest)
        elif k == "support":
            r[k] = [int(x) for x in rest.split()]
        else:
            r[k] = rest
    return r


def generate(recipe, seed, ifo):
    import area as A  # needs the install-derived donor data only for the JSON build
    pack = Pack(recipe["tilepack"])
    # the C app reads the binary GFF; this model reads the JSON export beside it
    tpl_are = json.load(open(recipe["template_are"].rsplit(".", 1)[0] + ".json"))
    tpl_git = json.load(open(recipe["template_git"].rsplit(".", 1)[0] + ".json"))
    donor = {"are": tpl_are, "git": tpl_git}
    tr_t = tpl_git["TriggerList"]["value"][0]
    areas = recipe["areas"]
    plan = plan_areas(recipe, seed, pack)
    out = {}
    for i, (a, lay, tiles, pairs) in enumerate(plan):
        res = a["resref"]; U = res.upper()
        wps, trs = [], []

        def direction(frm, to):
            dx, dy = to[0] - frm[0], to[1] - frm[1]
            n = (dx * dx + dy * dy) ** 0.5
            return dx / n, dy / n

        def cc(c): return cell_center(*c)
        if "prev" in pairs:
            portal, arrive = pairs["prev"]
            wps.append(A.make_waypoint("WP_%s_FWD" % U, *cc(arrive), *direction(cc(portal), cc(arrive)), name="Arrive %s" % U))
            trs.append(A.make_transition(tr_t, "TR_%s_PREV" % U, "WP_%s_BACK" % plan[i - 1][0]["resref"].upper(), *cc(portal), name="Back up"))
        if "next" in pairs:
            portal, arrive = pairs["next"]
            wps.append(A.make_waypoint("WP_%s_BACK" % U, *cc(arrive), *direction(cc(portal), cc(arrive)), name="Back in %s" % U))
            trs.append(A.make_transition(tr_t, "TR_%s_NEXT" % U, "WP_%s_FWD" % plan[i + 1][0]["resref"].upper(), *cc(portal), name="Deeper"))
        are = A.build_are(pack, donor, res, a["name"], U, lay, tiles)
        git = A.build_git(donor, wps)
        git["TriggerList"] = v("list", trs)
        out[res] = (are, git, A.build_gic(git), lay)
    start, nb = plan[0][3]["start"]
    sx, sy = cell_center(*start)
    ifo = json.loads(json.dumps(ifo))
    ifo["Mod_Name"] = v("cexolocstring", {"0": recipe["module_name"]})
    ifo["Mod_Description"] = v("cexolocstring", {"0": recipe.get("module_description", "")})
    ifo["Mod_Area_list"] = v("list", [{"__struct_id": 6, "Area_Name": v("resref", a["resref"])} for a in areas])
    ifo["Mod_Entry_Area"] = v("resref", areas[0]["resref"])
    ifo["Mod_Entry_X"], ifo["Mod_Entry_Y"], ifo["Mod_Entry_Z"] = v("float", sx), v("float", sy), v("float", 0.0)
    nx, ny = cell_center(*nb)
    dx, dy = nx - sx, ny - sy
    n = (dx * dx + dy * dy) ** 0.5
    ifo["Mod_Entry_Dir_X"], ifo["Mod_Entry_Dir_Y"] = v("float", dx / n), v("float", dy / n)
    ifo["Mod_Tag"] = v("cexostring", recipe["module_tag"])
    import base64
    ifo["Mod_ID"] = {"type": "void", "value64": base64.b64encode(module_id(seed, recipe["module_tag"])).decode()}
    return out, ifo


if __name__ == "__main__":
    if sys.argv[1] == "--dump":  # chain_ref.py --dump RECIPE SEED : pure plan, no install needed
        rec = parse_recipe(sys.argv[2])
        sys.stdout.write(dump(plan_areas(rec, int(sys.argv[3]), Pack(rec["tilepack"])), int(sys.argv[3])))
        sys.exit(0)
    recipe_p, seed, ifo_p, outdir = sys.argv[1], int(sys.argv[2]), sys.argv[3], sys.argv[4]
    recipe = parse_recipe(recipe_p)
    out, ifo = generate(recipe, seed, json.load(open(ifo_p)))
    os.makedirs(outdir, exist_ok=True)
    json.dump(ifo, open(os.path.join(outdir, "module.ifo.json"), "w"), sort_keys=True)
    for res, (are, git, gic, lay) in out.items():
        for obj, ext in ((are, "are"), (git, "git"), (gic, "gic")):
            json.dump(obj, open(os.path.join(outdir, "%s.%s.json" % (res, ext)), "w"), sort_keys=True)
        print(res, "layout attempts", lay["attempts"]); print(render(lay))
