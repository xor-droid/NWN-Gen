"""Shared helpers for the AUTHORING-TIME pack builder (never a runtime dependency).

Environment:
  NWN_ROOT    NWN:EE install dir ("Neverwinter Nights")
  NWN_TOOLS   directory holding the neverwinter.nim 2.3.1 binaries
  NWN_WORK    scratch directory for extracted data
"""
import json
import os
import subprocess
import sys

sys.dont_write_bytecode = True


def env(name):
    v = os.environ.get(name)
    if not v:
        sys.exit("set %s (see tools/pack/README.md)" % name)
    return v


ROOT = lambda: env("NWN_ROOT")
TOOLS = lambda: env("NWN_TOOLS")
WORK = lambda: env("NWN_WORK")


def tool(name, *args, check=True, cwd=None):
    exe = os.path.join(TOOLS(), name)
    r = subprocess.run([exe] + list(args), capture_output=True, text=True, cwd=cwd)
    if check and r.returncode != 0:
        sys.exit("%s failed: %s" % (name, r.stderr.strip()[-500:]))
    return r


def resman_args():
    return ["--root", ROOT(), "--userdirectory", os.path.join(WORK(), "userdir")]


def extract_stock(names, outdir):
    """Extract stock resources (e.g. 'tdc01.set') through the game's resman stack."""
    os.makedirs(outdir, exist_ok=True)
    os.makedirs(os.path.join(WORK(), "userdir"), exist_ok=True)
    tool("nwn_resman_extract", *resman_args(), "-d", outdir, *names)


def gff_to_json(path):
    r = tool("nwn_gff", "-i", path, "-o", "-", "-k", "json")
    return json.loads(r.stdout)


def json_to_gff(obj, path):
    p = subprocess.run([os.path.join(TOOLS(), "nwn_gff"), "-i", "-", "-l", "json", "-o", path],
                       input=json.dumps(obj), capture_output=True, text=True)
    if p.returncode != 0:
        sys.exit("nwn_gff json->gff failed: " + p.stderr[-400:])


def stock_archives():
    d = ROOT()
    out = []
    for sub, ext in (("data/mod", ".mod"), ("data/nwm", ".nwm")):
        p = os.path.join(d, sub)
        for f in sorted(os.listdir(p)):
            if f.lower().endswith(ext):
                out.append(os.path.join(p, f))
    return out


def parse_set(path):
    """Parse a tileset .set into {'tiles': [...], 'general': {...}} (no external deps)."""
    sec, cur, data = None, None, {}
    with open(path, encoding="latin-1") as f:
        for line in f:
            line = line.strip()
            if line.startswith("[") and line.endswith("]"):
                sec = line[1:-1]
                data[sec] = {}
            elif "=" in line and sec is not None:
                k, v = line.split("=", 1)
                data[sec][k] = v
    n = int(data["TILES"]["Count"])
    tiles = [data["TILE%d" % i] for i in range(n)]
    return {"general": data["GENERAL"], "tiles": tiles, "raw": data}
