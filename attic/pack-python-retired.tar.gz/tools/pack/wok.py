"""Minimal NWN1 ASCII tile-walkmesh (.wok) reader: walkable area and point tests."""
import struct


def read_wok(data):
    """Parse an NWN1 ASCII tile walkmesh (#MAXWALKMESH). Coordinates are relative to the
    tile centre (-5..5). Returns (verts, faces, mats); material is the last face column."""
    text = data.decode("latin-1") if isinstance(data, bytes) else data
    assert "beginwalkmeshgeom" in text, text[:40]
    verts, faces, mats = [], [], []
    lines = text.splitlines()
    i = 0
    while i < len(lines):
        t = lines[i].split()
        if t[:1] == ["verts"]:
            for j in range(int(t[1])):
                verts.append(tuple(float(x) for x in lines[i + 1 + j].split()[:3]))
            i += int(t[1])
        elif t[:1] == ["faces"]:
            for j in range(int(t[1])):
                c = lines[i + 1 + j].split()
                faces.append((int(c[0]), int(c[1]), int(c[2])))
                mats.append(int(c[-1]))
            i += int(t[1])
        i += 1
    return verts, faces, mats


def walkable_materials(surfacemat_2da_text):
    """Parse surfacemat.2da text -> set of material ids whose Walk column is 1."""
    lines = [l for l in surfacemat_2da_text.splitlines() if l.strip()]
    hdr = lines[1].split()
    wi = hdr.index("Walk")
    ok = set()
    for l in lines[2:]:
        c = l.split()
        if len(c) > wi + 1 and c[wi + 1] == "1":
            ok.add(int(c[0]))
    return ok


def _tri_area(a, b, c):
    return abs((b[0] - a[0]) * (c[1] - a[1]) - (c[0] - a[0]) * (b[1] - a[1])) / 2


def walk_area(verts, faces, mats, ok):
    return sum(_tri_area(verts[a], verts[b], verts[c]) for (a, b, c), m in zip(faces, mats) if m in ok)


def point_walkable(verts, faces, mats, ok, x, y):
    for (a, b, c), m in zip(faces, mats):
        if m not in ok:
            continue
        A, B, C = verts[a], verts[b], verts[c]
        d = (B[1] - C[1]) * (A[0] - C[0]) + (C[0] - B[0]) * (A[1] - C[1])
        if d == 0:
            continue
        l1 = ((B[1] - C[1]) * (x - C[0]) + (C[0] - B[0]) * (y - C[1])) / d
        l2 = ((C[1] - A[1]) * (x - C[0]) + (A[0] - C[0]) * (y - C[1])) / d
        if l1 >= -1e-6 and l2 >= -1e-6 and 1 - l1 - l2 >= -1e-6:
            return True
    return False
