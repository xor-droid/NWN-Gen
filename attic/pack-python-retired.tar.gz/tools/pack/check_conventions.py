"""Step 1b (hard gate): find which index-order x rotation-direction convention yields
ZERO adjacency violations over every stock area of the given tilesets.
usage: check_conventions.py stock_areas.json"""
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *  # noqa
from tiles import ORDERS, violations

stock = json.load(open(sys.argv[1]))
sets = {}
for arc in stock.values():
    for a in arc.values():
        sets.setdefault(a["tileset"], None)
for ts in sets:
    d = os.path.join(WORK(), "sets"); extract_stock([ts + ".set"], d)
    sets[ts] = parse_set(os.path.join(d, ts + ".set"))["tiles"]
    print(ts, len(sets[ts]), "tiles")
print("convention                     areas  violating-areas  total-violations")
for ts in sets:
    areas = [a for arc in stock.values() for a in arc.values() if a["tileset"] == ts]
    for order in ORDERS:
        for ccw in (True, False):
            tot = bad_areas = 0
            for a in areas:
                v = violations(a, sets[ts], order, ccw)
                tot += v
                bad_areas += v > 0
            print("%-6s %-11s %-4s %9d %12d %14d" % (ts, order, "ccw" if ccw else "cw", len(areas), bad_areas, tot))
