"""Vertical slice 1: ONE procedural TDC01 room module, no scripts, no transitions.
usage: build_slice.py SEED OUT.mod [--W n --H n --rooms n]
Needs NWN_ROOT, NWN_TOOLS, NWN_WORK, and the packer build/erfpack (env ERFPACK)."""
import base64
import hashlib
import json
import os
import shutil
import subprocess
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from area import *  # noqa
from layout import make_layout, render, full_floor_cells, components
from rng import Rng

seed = int(sys.argv[1])
out = sys.argv[2]
W, H, NR = 8, 8, 3
rng = Rng(seed)
kit = Kit()
donor = load_donor()
lay = make_layout(rng, W, H, NR)
tiles = pick_tiles(kit, lay, rng)
resref = "slice_room"
are = build_are(kit, donor, resref, "Shifting Cellars - layout test", "SLICE_ROOM", lay, tiles)
git = build_git(donor)
gic = build_gic(git)
probs = validate_area(kit, lay, tiles, are)
assert not probs, probs
print(render(lay))
print("layout attempts:", lay["attempts"], " rooms:", lay["rooms"])

# start in the first room's centre-most full-floor cell
ff = sorted(full_floor_cells(lay["lat"], W, H))
r = lay["rooms"][0]
cands = [c for c in ff if r[0] <= c[0] < r[2] and r[1] <= c[1] < r[3]]
sx, sy = cands[len(cands) // 2]
cx, cy = cell_center(sx, sy)
print("start cell", (sx, sy), "world", (cx, cy))

# modules donor: The Dark Ranger's Treasure (stock IFO + faction file)
W_ = WORK()
dr = os.path.join(W_, "donor_mod"); shutil.rmtree(dr, ignore_errors=True); os.makedirs(dr)
src = os.path.join(ROOT(), "data", "mod", "The Dark Ranger's Treasure.mod")
tool("nwn_erf", "-f", src, "-x", cwd=dr)  # whole donor module (small); names are case-mixed
found = {f.lower(): f for f in os.listdir(dr)}
ifo = gff_to_json(os.path.join(dr, found["module.ifo"]))
ifo["Mod_Name"] = v("cexolocstring", {"0": "The Shifting Cellars (layout test)"})
ifo["Mod_Description"] = v("cexolocstring", {"0": "Format-slice 1: one generated TDC01 room. No monsters, no objective."})
ifo["Mod_Area_list"] = v("list", [{"__struct_id": 6, "Area_Name": v("resref", resref)}])
ifo["Mod_Entry_Area"] = v("resref", resref)
ifo["Mod_Entry_X"], ifo["Mod_Entry_Y"], ifo["Mod_Entry_Z"] = v("float", cx), v("float", cy), v("float", 0.0)
ifo["Mod_Entry_Dir_X"], ifo["Mod_Entry_Dir_Y"] = v("float", 0.0), v("float", 1.0)
ifo["Mod_Tag"] = v("cexostring", "SHIFTING_CELLARS")
mid = hashlib.sha256(("nwngen-slice1/%d" % seed).encode()).digest()[:16]
ifo["Mod_ID"] = {"type": "void", "value64": base64.b64encode(mid).decode()}
for k in [k for k in ifo if k.startswith("Mod_On")]:
    ifo[k] = v("resref", "")
# keep the stock death/respawn handlers so dying does not strand the player
for k, s in (("Mod_OnPlrDeath", "nw_o0_death"), ("Mod_OnPlrDying", "nw_o0_dying"), ("Mod_OnSpawnBtnDn", "nw_o0_respawn")):
    ifo[k] = v("resref", s)

stage = os.path.join(W_, "slice_stage"); shutil.rmtree(stage, ignore_errors=True); os.makedirs(stage)
json_to_gff(ifo, os.path.join(stage, "module.ifo"))
shutil.copy(os.path.join(dr, found["repute.fac"]), os.path.join(stage, "repute.fac"))
json_to_gff(are, os.path.join(stage, resref + ".are"))
json_to_gff(git, os.path.join(stage, resref + ".git"))
json_to_gff(gic, os.path.join(stage, resref + ".gic"))
subprocess.run([os.environ["ERFPACK"], "nwn1", "MOD", out, stage], check=True)

# round-trip: re-read what we wrote and re-run the stock-proven adjacency check
back = gff_to_json(os.path.join(stage, resref + ".are"))
assert back["Width"]["value"] == W and len(back["Tile_List"]["value"]) == W * H
area = {"width": W, "height": H, "tiles": [{k: x["value"] for k, x in t.items() if k != "__struct_id"} for t in back["Tile_List"]["value"]]}
assert violations(area, kit.tiles, "row_bottom", True) == 0
print("round-trip adjacency violations: 0")
