"""Export the stock-proven tile pool + light table for TDC01 as a text file that both the
Python reference and the C generator read.  usage: export_tilepack.py OUT.txt"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from area import Kit  # noqa
Kit().export_tilepack(sys.argv[1])
