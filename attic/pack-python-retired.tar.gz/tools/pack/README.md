# Pack builder (authoring time only)

Builds NWN:EE adventure content **locally from your own install**. Nothing from the game
is stored in this repository; the scripts read your install and write to a scratch dir.
These scripts only read your install to produce data files; the generator (`nwndgen`) and its
tests are POSIX C, and layout/tile generation now lives in C (`src/dungeon.c`). Porting these
extraction scripts to C is possible but not done.

Requires: NWN:EE install, neverwinter.nim 2.3.1 binaries (`nwn_gff`, `nwn_erf`,
`nwn_resman_extract`), and `make` (for `build/erfpack`).

```sh
export NWN_ROOT="/mnt/c/Program Files (x86)/Steam/steamapps/common/Neverwinter Nights"
export NWN_TOOLS=/path/to/neverwinter-tools   # dir with nwn_gff, nwn_erf, ...
export NWN_WORK=/path/to/scratch
export ERFPACK=$PWD/build/erfpack
mkdir -p $NWN_WORK
python3 -I tools/pack/scan_stock_areas.py $NWN_WORK/stock_areas.json tdc01 tin01
python3 -I tools/pack/scan_tdc_full.py    $NWN_WORK/tdc_full.json tdc01
python3 -I tools/pack/check_conventions.py $NWN_WORK/stock_areas.json   # hard gate
python3 -I tools/pack/build_slice.py 1 build/slices/shifting_cellars_slice1.mod
```

## Feeding the C generator

```sh
python3 -I tools/pack/export_templates.py $NWN_WORK/dg      # tpl_are/tpl_git (+ .json), base_module.mod, base_ifo.json
cp $NWN_WORK/tilepack_tdc01.txt $NWN_WORK/dg/               # from export_tilepack.py
build/nwndgen --game nwn1 --base $NWN_WORK/dg/base_module.mod --recipe my_recipe.txt --seed 1 --output out.mod
python3 -I tools/pack/compare_c.py my_recipe.txt 1 $NWN_WORK/dg/base_ifo.json out.mod   # field-by-field check
```

`chain_ref.py` is the Python reference model of the C generator (same recipe/tilepack files);
`compare_c.py` extracts the C-written module, compares every resource with it through
`nwn_gff`, and re-checks tile adjacency with the stock-proven rules.

## Why these steps

* `check_conventions.py` is a hard gate: of 8 tile-index/rotation conventions exactly one
  (rows from the south, west->east; orientation = counter-clockwise quarter turns) gives
  zero corner/edge/height mismatches over all 232 stock `tdc01`/`tin01` areas.
* Layouts live on the **corner lattice**: choose Wall/Floor for each vertex, and every cell
  then needs a tile with those four corners. Only tiles that stock areas actually place
  (basic `tdc01_a*` pieces; fully-walkable floors verified from the game's own `.wok`
  walkmeshes) are used, and diagonal corner patterns (which stock never tiles) are forbidden.
* ARE header, AreaProperties, per-tile lighting, IFO and `repute.fac` are copied from stock
  donors (`Chapter1.nwm:map_m1s1e`, *The Dark Ranger's Treasure*); only identity, size,
  tiles and object lists are ours. `nwn_gff` JSON round-trips all of them exactly.
* Builds are deterministic (own SplitMix64, sorted iteration, `erfpack` canonical ERF).

## Status

Slice 1 (one room) loaded and walked in the game (user-reported). Slice 2 (two areas + transition) is
built; load test pending. `nwndgen --recipe` modules (`build/dungeon/shifting_cellars_seed*.mod`) are
statically validated only: **not loaded in the game yet.** Next: scripts/spawns/objectives.
