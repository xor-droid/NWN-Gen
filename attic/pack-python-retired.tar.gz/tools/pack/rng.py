"""SplitMix64 for the pack builder (same generator as the C app; Python's `random`
is not guaranteed stable across versions, and pack builds must be reproducible)."""
M64 = (1 << 64) - 1


class Rng:
    def __init__(self, seed):
        self.s = seed & M64

    def next(self):
        self.s = (self.s + 0x9E3779B97F4A7C15) & M64
        z = self.s
        z = ((z ^ (z >> 30)) * 0xBF58476D1CE4E5B9) & M64
        z = ((z ^ (z >> 27)) * 0x94D049BB133111EB) & M64
        return z ^ (z >> 31)

    def below(self, n):
        assert n > 0
        thr = ((1 << 64) - n) % n
        while True:
            v = self.next()
            if v >= thr:
                return v % n

    def range(self, lo, hi):  # inclusive
        return lo + self.below(hi - lo + 1)

    def pick(self, seq):
        return seq[self.below(len(seq))]

    def weighted(self, items):
        """items: [(weight, value)] -> value (stable order required from caller)."""
        total = sum(w for w, _ in items)
        r = self.below(total)
        for w, v in items:
            if r < w:
                return v
            r -= w
        raise AssertionError
