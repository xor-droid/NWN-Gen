"""Build ARE / GIT / GIC (as nwn_gff JSON) for a procedural TDC01 layout.

Everything structural is copied from real stock data (donor area, donor AreaProperties,
per-tile light values); only identity, size, tiles and object lists are ours.
"""
import collections
import copy
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *  # noqa
from layout import cell_sig, full_floor_cells
from rng import Rng
from tiles import tile_sig, violations
from wok import read_wok, walk_area, point_walkable, walkable_materials

TILESET = "tdc01"
DONOR_AREA = "Chapter1.nwm:map_m1s1e"  # stock tdc01 area: Flags=3, lit, no scripts
CLEAN_FLOOR_MODELS = ("tdc01_a09_01", "tdc01_o01_01", "tdc01_o05_01", "tdc01_o06_01", "tdc01_o01_02")
FLOOR_WEIGHT = {"tdc01_a09_01": 6}  # plain floor dominates; decorated floors are rarer


def v(t, x):
    return {"type": t, "value": x}


class Kit:
    """Tileset data + stock-derived pool, loaded from the user's install."""

    def __init__(self):
        W = WORK()
        sa = os.path.join(W, "stock_areas.json")
        if not os.path.exists(sa):
            sys.exit("run: scan_stock_areas.py %s tdc01 tin01   (see README)" % sa)
        stock = json.load(open(sa))
        d = os.path.join(W, "sets")
        extract_stock([TILESET + ".set"], d)
        self.tiles = parse_set(os.path.join(d, TILESET + ".set"))["tiles"]
        use = collections.Counter()
        light = collections.defaultdict(collections.Counter)
        for arc in sorted(stock):
            for an in sorted(stock[arc]):
                a = stock[arc][an]
                if a["tileset"] != TILESET:
                    continue
                for t in a["tiles"]:
                    use[(t["Tile_ID"], t["Tile_Orientation"])] += 1
                    light[t["Tile_ID"]][(t["Tile_MainLight1"], t["Tile_MainLight2"], t["Tile_SrcLight1"],
                                         t["Tile_SrcLight2"], t["Tile_AnimLoop1"], t["Tile_AnimLoop2"],
                                         t["Tile_AnimLoop3"])] += 1
        self.light = {tid: sorted(c.items(), key=lambda kv: (-kv[1], kv[0]))[0][0] for tid, c in light.items()}
        # walkmeshes -> which floor tiles are fully walkable
        wd = os.path.join(W, "wok")
        extract_stock([m + ".wok" for m in CLEAN_FLOOR_MODELS] + ["surfacemat.2da"], wd)
        ok = walkable_materials(open(os.path.join(wd, "surfacemat.2da"), encoding="latin-1").read())
        self.clean_models = {}
        for m in CLEAN_FLOOR_MODELS:
            vv, ff, mm = read_wok(open(os.path.join(wd, m + ".wok"), "rb").read())
            assert walk_area(vv, ff, mm, ok) > 99.5 and point_walkable(vv, ff, mm, ok, 0, 0), m
            self.clean_models[m] = True
        self.pool = collections.defaultdict(list)  # sig -> [(weight, tid, orient)]
        for (tid, o), n in sorted(use.items()):
            t = self.tiles[tid]
            c, ch, e = tile_sig(t, o, True)
            if int(t.get("Doors", "0") or 0) > 0 or any(e.values()) or any(ch.values()):
                continue
            if any(x not in ("Wall", "Floor") for x in c.values()):
                continue
            sig = tuple("F" if c[p] == "Floor" else "W" for p in ("NW", "NE", "SW", "SE"))
            model = t["Model"]
            if sig == ("F",) * 4:
                if model in self.clean_models:
                    self.pool[sig].append((FLOOR_WEIGHT.get(model, 1), tid, o))
            elif model.startswith("tdc01_a"):  # basic wall/floor pieces only
                self.pool[sig].append((n, tid, o))
        for sig in self.pool:
            self.pool[sig].sort(key=lambda x: (x[1], x[2]))

    def export_tilepack(self, path):
        """Write the pool + per-tile light values as the text file shared by Python and C."""
        lines = ["nwndgen-tilepack 1", "tileset " + TILESET]
        for sig in sorted(self.pool):
            for w, tid, o in sorted(self.pool[sig], key=lambda x: (x[1], x[2])):
                lines.append("cell %s %d %d %d" % ("".join(sig), w, tid, o))
        for tid in sorted(self.light):
            lines.append("light %d %s" % (tid, " ".join(str(x) for x in self.light[tid])))
        with open(path, "w", newline="") as f:
            f.write("\n".join(lines) + "\n")

    def load_tilepack(self, path):
        """Replace pool/light with the exported file (single source of truth for C)."""
        pool = collections.defaultdict(list)
        light = {}
        for line in open(path).read().splitlines()[2:]:
            t = line.split()
            if t[0] == "cell":
                pool[tuple(t[1])].append((int(t[2]), int(t[3]), int(t[4])))
            elif t[0] == "light":
                light[int(t[1])] = tuple(int(x) for x in t[2:])
        self.pool, self.light = pool, light

    def tile_for(self, rng, sig):
        c = self.pool.get(sig)
        if not c:
            raise KeyError("no stock-proven tile for corner pattern %s" % (sig,))
        return rng.weighted([(w, (tid, o)) for w, tid, o in c])


def load_donor():
    p = os.path.join(WORK(), "tdc_full.json")
    if not os.path.exists(p):
        sys.exit("run: scan_tdc_full.py %s tdc01" % p)
    return json.load(open(p))[DONOR_AREA]


def pick_tiles(kit, layout, rng):
    W, H, lat = layout["W"], layout["H"], layout["lat"]
    out = []
    for y in range(H):
        for x in range(W):
            tid, o = kit.tile_for(rng, cell_sig(lat, x, y))
            out.append((tid, o))
    return out


def build_are(kit, donor, resref, name, tag, layout, tiles, scripts=None, local_vars=None):
    are = copy.deepcopy(donor["are"])
    W, H = layout["W"], layout["H"]
    are["Width"] = v("int", W)
    are["Height"] = v("int", H)
    are["ResRef"] = v("resref", resref)
    are["Tag"] = v("cexostring", tag)
    are["Name"] = v("cexolocstring", {"0": name})
    are["Comments"] = v("cexostring", "generated by nwndgen")
    are["ID"] = v("int", -1)
    are["Creator_ID"] = v("int", -1)
    are["Version"] = v("dword", 18)
    are["Tileset"] = v("resref", TILESET)
    for ev in ("OnEnter", "OnExit", "OnHeartbeat", "OnUserDefined"):
        are[ev] = v("resref", (scripts or {}).get(ev, ""))
    tl = []
    for tid, o in tiles:
        ml1, ml2, sl1, sl2, a1, a2, a3 = kit.light[tid]
        tl.append({"__struct_id": 1,
                   "Tile_AnimLoop1": v("byte", a1), "Tile_AnimLoop2": v("byte", a2), "Tile_AnimLoop3": v("byte", a3),
                   "Tile_Height": v("int", 0), "Tile_ID": v("int", tid),
                   "Tile_MainLight1": v("byte", ml1), "Tile_MainLight2": v("byte", ml2),
                   "Tile_Orientation": v("int", o),
                   "Tile_SrcLight1": v("byte", sl1), "Tile_SrcLight2": v("byte", sl2)})
    are["Tile_List"] = v("list", tl)
    if local_vars:
        are["VarTable"] = v("list", local_vars)
    return are


GIT_LISTS = ["Creature List", "Door List", "Encounter List", "List", "Placeable List",
             "SoundList", "StoreList", "TriggerList", "WaypointList"]


def build_git(donor, waypoints=()):
    git = {"__data_type": "GIT ", "AreaProperties": copy.deepcopy(donor["git"]["AreaProperties"])}
    for k in GIT_LISTS:
        git[k] = v("list", [])
    git["WaypointList"] = v("list", list(waypoints))
    return git


def build_gic(git):
    """GIC mirrors every GIT list in length and order, one Comment struct per object."""
    gic = {"__data_type": "GIC "}
    for k in GIT_LISTS:
        gic[k] = v("list", [{"__struct_id": e["__struct_id"], "Comment": v("cexostring", "")}
                            for e in git[k]["value"]])
    return gic


def cell_center(x, y):
    return (x * 10.0 + 5.0, y * 10.0 + 5.0)


def validate_area(kit, layout, tiles, are):
    """Same adjacency function that gives 0 violations on every stock area, plus
    structural checks. Returns list of problems (empty = ok)."""
    W, H = layout["W"], layout["H"]
    problems = []
    if len(are["Tile_List"]["value"]) != W * H:
        problems.append("Tile_List length != Width*Height")
    area = {"width": W, "height": H,
            "tiles": [{k: x["value"] for k, x in t.items() if k != "__struct_id"} for t in are["Tile_List"]["value"]]}
    n = violations(area, kit.tiles, "row_bottom", True)
    if n:
        problems.append("%d adjacency violations" % n)
    for i, (tid, o) in enumerate(tiles):
        t = kit.tiles[tid]
        if int(t.get("Doors", "0") or 0):
            problems.append("door tile used at %d" % i)
    return problems


# ---- objects copied from real stock structs (field set identical to stock GIT entries) ----

def make_waypoint(tag, x, y, dx, dy, name=""):
    return {"__struct_id": 5, "Appearance": v("byte", 1), "Description": v("cexolocstring", {}),
            "HasMapNote": v("byte", 0), "LinkedTo": v("cexostring", ""),
            "LocalizedName": v("cexolocstring", {"0": name or tag}),
            "MapNote": v("cexolocstring", {}), "MapNoteEnabled": v("byte", 1),
            "Tag": v("cexostring", tag), "TemplateResRef": v("resref", "nw_waypoint001"),
            "XOrientation": v("float", dx), "YOrientation": v("float", dy),
            "XPosition": v("float", x), "YPosition": v("float", y), "ZPosition": v("float", 0.0)}


def make_transition(donor_trigger, tag, linked_wp_tag, x, y, half=3.0, name="Transition"):
    """Area-transition trigger (stock `newtransition`, Type=1) targeting a waypoint
    (LinkedToFlags=2, confirmed against stock data). Square CCW polygon of side 2*half."""
    t = copy.deepcopy(donor_trigger)
    t["Tag"] = v("cexostring", tag)
    t["LinkedTo"] = v("cexostring", linked_wp_tag)
    t["LinkedToFlags"] = v("byte", 2)
    t["LocalizedName"] = v("cexolocstring", {"0": name})
    t["XPosition"], t["YPosition"], t["ZPosition"] = v("float", x), v("float", y), v("float", 0.0)
    pts = [(-half, -half), (half, -half), (half, half), (-half, half)]
    t["Geometry"] = v("list", [{"__struct_id": 3, "PointX": v("float", px), "PointY": v("float", py),
                                "PointZ": v("float", 0.0)} for px, py in pts])
    return t


def donor_transition_trigger():
    """The real stock transition trigger used as the structural template."""
    d = json.load(open(os.path.join(WORK(), "tdc_full.json")))["Chapter2E.nwm:m2q4d_06"]["git"]
    for t in d["TriggerList"]["value"]:
        if t.get("LinkedTo", {}).get("value") and t["Type"]["value"] == 1:
            return t
    raise RuntimeError("stock transition trigger not found")


def trigger_contains(trig, x, y):
    cx, cy = trig["XPosition"]["value"], trig["YPosition"]["value"]
    pts = [(cx + p["PointX"]["value"], cy + p["PointY"]["value"]) for p in trig["Geometry"]["value"]]
    inside = False
    for i in range(len(pts)):
        (x1, y1), (x2, y2) = pts[i], pts[(i + 1) % len(pts)]
        if (y1 > y) != (y2 > y) and x < (x2 - x1) * (y - y1) / (y2 - y1) + x1:
            inside = not inside
    return inside
