"""Vertical slice 2: TWO procedural TDC01 areas joined by area-transition triggers.
Area A (module entry) -> trigger TR_A_NEXT -> waypoint WP_B_ARRIVE_FWD in area B;
area B -> trigger TR_B_PREV -> waypoint WP_A_ARRIVE_BACK in area A. No scripts/monsters.
usage: build_slice2.py SEED OUT.mod   (env as in README)"""
import base64, hashlib, json, os, shutil, subprocess, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from area import *  # noqa
from layout import make_layout, render, full_floor_cells, components, portal_pair, cell_sig
from rng import Rng

seed, out = int(sys.argv[1]), sys.argv[2]
W, H = 8, 8
kit, donor, trig_t = Kit(), load_donor(), donor_transition_trigger()


def center_dir(frm, to):
    dx, dy = to[0] - frm[0], to[1] - frm[1]
    n = (dx * dx + dy * dy) ** 0.5
    return dx / n, dy / n


areas = {}
for name, nrooms in (("a", 3), ("b", 3)):
    rng = Rng(seed * 1000 + (1 if name == "a" else 2))
    lay = make_layout(rng, W, H, nrooms)
    tiles = pick_tiles(kit, lay, rng)
    areas[name] = {"lay": lay, "tiles": tiles, "rng": rng}
    print("area", name, "rooms", lay["rooms"], "attempts", lay["attempts"])
    print(render(lay))

# A: entry/start in room 0; exit portal + back-arrival in the LAST room.
# B: entry portal + forward-arrival in room 0.
A, B = areas["a"], areas["b"]
a_start, a_start_nb = portal_pair(A["lay"], 0, A["rng"])
a_portal, a_arrive = portal_pair(A["lay"], len(A["lay"]["rooms"]) - 1, A["rng"])
b_portal, b_arrive = portal_pair(B["lay"], 0, B["rng"])

def cc(c): return cell_center(*c)

wpA = make_waypoint("WP_A_ARRIVE_BACK", *cc(a_arrive), *center_dir(cc(a_portal), cc(a_arrive)), name="Back in A")
wpB = make_waypoint("WP_B_ARRIVE_FWD", *cc(b_arrive), *center_dir(cc(b_portal), cc(b_arrive)), name="Arrive in B")
trA = make_transition(trig_t, "TR_A_NEXT", "WP_B_ARRIVE_FWD", *cc(a_portal), name="Deeper")
trB = make_transition(trig_t, "TR_B_PREV", "WP_A_ARRIVE_BACK", *cc(b_portal), name="Back up")

res = {"a": "scel_a", "b": "scel_b"}
files = {}
for key, wp, tr in (("a", wpA, trA), ("b", wpB, trB)):
    ar = areas[key]
    are = build_are(kit, donor, res[key], "Shifting Cellars - %s" % key.upper(), "SCEL_" + key.upper(), ar["lay"], ar["tiles"])
    git = build_git(donor, [wp]); git["TriggerList"] = v("list", [tr])
    gic = build_gic(git)
    probs = validate_area(kit, ar["lay"], ar["tiles"], are)
    assert not probs, probs
    files[key] = (are, git, gic)

# ---- cross-area validation ----
wps = {}; trs = []
for key, (are, git, gic) in files.items():
    for w in git["WaypointList"]["value"]: wps[w["Tag"]["value"]] = (key, w)
    for t in git["TriggerList"]["value"]: trs.append((key, t))
for key, t in trs:
    tgt = t["LinkedTo"]["value"]
    assert tgt in wps and wps[tgt][0] != key, "transition %s has no waypoint in the other area" % t["Tag"]["value"]
    assert t["LinkedToFlags"]["value"] == 2
for key, (are, git, gic) in files.items():           # GIC mirrors GIT
    for k in GIT_LISTS:
        assert [e["__struct_id"] for e in git[k]["value"]] == [e["__struct_id"] for e in gic[k]["value"]], k
for key, lay in (("a", A["lay"]), ("b", B["lay"])):  # every placed object on a full-floor cell, none inside a foreign trigger
    ff = full_floor_cells(lay["lat"], W, H)
    git = files[key][1]
    for w in git["WaypointList"]["value"]:
        c = (int(w["XPosition"]["value"] // 10), int(w["YPosition"]["value"] // 10))
        assert c in ff, (key, w["Tag"]["value"], c)
        for t in git["TriggerList"]["value"]:
            assert not trigger_contains(t, w["XPosition"]["value"], w["YPosition"]["value"]), "arrival inside a transition trigger (ping-pong)"
    for t in git["TriggerList"]["value"]:
        c = (int(t["XPosition"]["value"] // 10), int(t["YPosition"]["value"] // 10))
        assert c in ff
sx, sy = cc(a_start)
assert (int(sx // 10), int(sy // 10)) in full_floor_cells(A["lay"]["lat"], W, H)
assert not trigger_contains(trA, sx, sy)
print("cross-area validation ok: start", (sx, sy), "A portal", cc(a_portal), "B portal", cc(b_portal))

# ---- module ----
W_ = WORK()
dr = os.path.join(W_, "donor_mod"); shutil.rmtree(dr, ignore_errors=True); os.makedirs(dr)
tool("nwn_erf", "-f", os.path.join(ROOT(), "data", "mod", "The Dark Ranger's Treasure.mod"), "-x", cwd=dr)
found = {f.lower(): f for f in os.listdir(dr)}
ifo = gff_to_json(os.path.join(dr, found["module.ifo"]))
ifo["Mod_Name"] = v("cexolocstring", {"0": "The Shifting Cellars (slice 2: transition test)"})
ifo["Mod_Description"] = v("cexolocstring", {"0": "Two generated TDC01 areas joined by transitions. No monsters, no objective."})
ifo["Mod_Area_list"] = v("list", [{"__struct_id": 6, "Area_Name": v("resref", res[k])} for k in ("a", "b")])
ifo["Mod_Entry_Area"] = v("resref", res["a"])
ifo["Mod_Entry_X"], ifo["Mod_Entry_Y"], ifo["Mod_Entry_Z"] = v("float", sx), v("float", sy), v("float", 0.0)
dx, dy = center_dir(cc(a_start), cc(a_start_nb))
ifo["Mod_Entry_Dir_X"], ifo["Mod_Entry_Dir_Y"] = v("float", dx), v("float", dy)
ifo["Mod_Tag"] = v("cexostring", "SHIFTING_CELLARS")
ifo["Mod_ID"] = {"type": "void", "value64": base64.b64encode(hashlib.sha256(("nwngen-slice2/%d" % seed).encode()).digest()[:16]).decode()}
for k in [k for k in ifo if k.startswith("Mod_On")]:
    ifo[k] = v("resref", "")
for k, s in (("Mod_OnPlrDeath", "nw_o0_death"), ("Mod_OnPlrDying", "nw_o0_dying"), ("Mod_OnSpawnBtnDn", "nw_o0_respawn")):
    ifo[k] = v("resref", s)
stage = os.path.join(W_, "slice2_stage"); shutil.rmtree(stage, ignore_errors=True); os.makedirs(stage)
json_to_gff(ifo, os.path.join(stage, "module.ifo"))
shutil.copy(os.path.join(dr, found["repute.fac"]), os.path.join(stage, "repute.fac"))
for key, (are, git, gic) in files.items():
    for obj, ext in ((are, "are"), (git, "git"), (gic, "gic")):
        json_to_gff(obj, os.path.join(stage, "%s.%s" % (res[key], ext)))
subprocess.run([os.environ["ERFPACK"], "nwn1", "MOD", out, stage], check=True)

# read back from disk and re-check what was actually written
for key in ("a", "b"):
    g = gff_to_json(os.path.join(stage, res[key] + ".git"))
    assert g == files[key][1], "GIT round-trip changed"
    a = gff_to_json(os.path.join(stage, res[key] + ".are"))
    area = {"width": W, "height": H, "tiles": [{k: x["value"] for k, x in t.items() if k != "__struct_id"} for t in a["Tile_List"]["value"]]}
    assert violations(area, kit.tiles, "row_bottom", True) == 0
print("written files re-read: GIT identical, adjacency violations 0")
