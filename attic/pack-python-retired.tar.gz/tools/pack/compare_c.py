"""Compare a .mod written by `nwndgen --recipe` with the Python reference model, field by field.

usage: compare_c.py RECIPE SEED BASE_IFO.json MOD.mod
Extracts the module with nwn_erf, converts every resource to JSON with nwn_gff, rebuilds the
expected resources with chain_ref.py (round-tripped through nwn_gff too, so float32 and
field-type normalisation are identical) and reports every difference. Also re-checks tile
adjacency of every generated area with the stock-proven rules (needs the tileset .set files in
$NWN_WORK/sets, see check_conventions.py)."""
import json
import os
import shutil
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import tool, gff_to_json, json_to_gff, WORK  # noqa
import chain_ref


def norm(obj, tmp, name):
    p = os.path.join(tmp, name)
    json_to_gff(obj, p)
    return gff_to_json(p)


def main():
    recipe_p, seed, ifo_p, mod = sys.argv[1], int(sys.argv[2]), sys.argv[3], sys.argv[4]
    tmp = os.path.join(WORK(), "cmp_tmp")
    shutil.rmtree(tmp, ignore_errors=True)
    os.makedirs(tmp + "/x")
    tool("nwn_erf", "-f", os.path.abspath(mod), "-x", cwd=tmp + "/x")
    recipe = chain_ref.parse_recipe(recipe_p)
    out, ifo = chain_ref.generate(recipe, seed, json.load(open(ifo_p)))
    want = {"module.ifo": ifo}
    for res, (are, git, gic, _lay) in out.items():
        want[res + ".are"], want[res + ".git"], want[res + ".gic"] = are, git, gic
    bad = 0
    for name, obj in sorted(want.items()):
        got = gff_to_json(os.path.join(tmp, "x", name))
        exp = norm(obj, tmp, "ref_" + name)
        if got != exp:
            bad += 1
            keys = sorted(set(got) | set(exp))
            for k in keys:
                if got.get(k) != exp.get(k):
                    print("DIFF %s field %s:\n  C   : %.300s\n  ref : %.300s" % (name, k, json.dumps(got.get(k)), json.dumps(exp.get(k))))
        else:
            print("ok  %s" % name)
    # independent re-check of the C-written bytes with the stock-proven adjacency rules
    import area as A
    kit = A.Kit()
    for res, (_a, _g, _c, lay) in out.items():
        are = gff_to_json(os.path.join(tmp, "x", res + ".are"))
        git = gff_to_json(os.path.join(tmp, "x", res + ".git"))
        tiles = [(t["Tile_ID"]["value"], t["Tile_Orientation"]["value"]) for t in are["Tile_List"]["value"]]
        problems = A.validate_area(kit, lay, tiles, are)
        for w in git["WaypointList"]["value"]:
            wx, wy = w["XPosition"]["value"], w["YPosition"]["value"]
            problems += ["waypoint %s inside trigger %s" % (w["Tag"]["value"], t["Tag"]["value"])
                         for t in git["TriggerList"]["value"] if A.trigger_contains(t, wx, wy)]
        print(("ok  " if not problems else "BAD ") + "%s tiles/waypoints %s" % (res, problems or ""))
        bad += bool(problems)
    extra = sorted(set(os.listdir(tmp + "/x")) - set(want) - {"repute.fac"})
    if extra:
        bad += 1
        print("unexpected resources:", extra)
    sys.exit(1 if bad else 0)


main()
