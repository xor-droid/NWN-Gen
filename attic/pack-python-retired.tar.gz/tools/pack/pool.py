"""Candidate tile pool for procedural layouts: only tiles that stock areas place,
with no doors/crossers/heights/pits, keyed by effective corner signature.
usage (analysis): pool.py stock_areas.json tileset"""
import collections
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *  # noqa
from tiles import tile_sig


def build_pool(stock, tileset, tiles, ccw=True):
    """Return {(NW,NE,SW,SE): [(count, tile_id, orientation), ...]} sorted by -count,
    and the usage counter, counting every placement of every tile in stock areas."""
    use = collections.Counter()
    for arc in stock.values():
        for a in arc.values():
            if a["tileset"] != tileset:
                continue
            for t in a["tiles"]:
                use[(t["Tile_ID"], t["Tile_Orientation"])] += 1
    pool = collections.defaultdict(list)
    for (tid, o), n in use.items():
        t = tiles[tid]
        c, ch, e = tile_sig(t, o, ccw)
        if int(t.get("Doors", "0") or 0) > 0 or any(e.values()) or any(ch.values()):
            continue
        if any(v not in ("Wall", "Floor") for v in c.values()):
            continue
        pool[(c["NW"], c["NE"], c["SW"], c["SE"])].append((n, tid, o))
    for k in pool:
        pool[k].sort(key=lambda x: (-x[0], x[1], x[2]))
    return pool, use


if __name__ == "__main__":
    stock = json.load(open(sys.argv[1])); ts = sys.argv[2]
    d = os.path.join(WORK(), "sets"); extract_stock([ts + ".set"], d)
    tiles = parse_set(os.path.join(d, ts + ".set"))["tiles"]
    pool, use = build_pool(stock, ts, tiles)
    print("tiles used by stock:", len({t for t, _ in use}), "of", len(tiles), "; placements:", sum(use.values()))
    print("signature (NW NE SW SE)        distinct-tiles  top candidates (count,tile,orient,model,walkmesh)")
    for a in ("Wall", "Floor"):
        for b in ("Wall", "Floor"):
            for c in ("Wall", "Floor"):
                for e in ("Wall", "Floor"):
                    k = (a, b, c, e)
                    v = pool.get(k, [])
                    top = ", ".join("(%d,%d,%d,%s,%s)" % (n, t, o, tiles[t]["Model"], tiles[t]["WalkMesh"]) for n, t, o in v[:3])
                    print("%-30s %5d   %s" % (" ".join(x[0] for x in k), len({t for _, t, _ in v}), top))
